Bienvenue dans PetRescue!
Les règles sont simples, il faut sauver les animaux en les faisant tomber au sol.
Pour cela il faut détruire des groupes d'au moins 2 blocs afin de faire tomber les blocs se trouvant sur le dessus.

Comment lancer le jeu :
    Rendez-vous avec un terminal dans le dossier Src
    Taper la commande "javac *.java" afin de compiler les fichiers du jeu
    Puis taper la commande "java Launcher"

Si vous voulez avoir directement accès à tous les niveaux, utiliser comme pseudo "Dev".