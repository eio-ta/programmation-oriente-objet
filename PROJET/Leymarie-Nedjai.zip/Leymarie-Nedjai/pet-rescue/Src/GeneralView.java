import java.io.*;

public abstract class GeneralView {
    protected Player player;
    protected String name;
    protected String screen;
    protected int currentLevel;
    protected int nLevels;

    public GeneralView(Player player){
        this.player = player;
        name = "";
        screen = "screenTitle";
        nLevels = new File("../Levels").list().length;
    }
    
}
