import java.util.Scanner;

/* This class interacts with the player thanks to a Scanner
 */
public class Communication{
    private Scanner sc;

    public Communication(){
        sc = new Scanner(System.in);
    }

    /* Takes a String and return true if it's an integer
     */
    public boolean isInt(String s){
        if(s.length() == 0) return false;
        for(int i = 0; i < s.length(); i++){
            char c = s.charAt(i);
            if(c < 48 || c > 57) return false;
        }
        return true;
    }

    /* Takes a String and return true if it's a String or a character
     */
    public boolean isLetter(String s){
        if(s.length() != 1) return false;
        char c = s.charAt(0);
        return (c >= 65 && c <= 90) || (c >= 97 && c <= 122);
    }

    /* Asks an integer, if acceptsLetters is true, the user can write "A" or "a" for 0, "B" or "b" for 1...
     */
    public int askNum(String text, boolean acceptsLetters){
        System.out.println(text);
        String s;
        boolean valid;
        do{
            s = sc.nextLine();
            valid = isInt(s) || (acceptsLetters && isLetter(s));
            if(!valid) System.out.println("Veuillez entrer un entier" + (acceptsLetters ? " ou une lettre" : ""));
        }while(!valid);
        int n;
        if(isLetter(s)){
            char c = s.charAt(0);
            if(c >= 97){
                n = c-97;
            } else {
                n = c-65;
            }
        } else {
            n = Integer.parseInt(s);
        }
        return n;
    }

    /* Take an Array of String and return one of the String that the user chooses
     */
    public String askPlay(String[] text){
        String choice;
        do{
            choice=sc.nextLine().toLowerCase();
            for(int i=0;i<text.length;i++){
                if(choice.equals(text[i])){
                    return choice;
                }
                
            }
        }while(true);
    }

    /* Asks the user the position of a block by callling function askNum
     */
    public int[] askPos(){
        int[] pos = new int[2];
        pos[0] = askNum("Ligne?", true);
        pos[1] = askNum("Colonne?", false);
        return pos;
    }

    // Allows the user to choose a level between 1 and max or to quit the level selection screen
    // returns -1 if the user has decided to quit
    public int askLevel(int max){
        String s;
        boolean valid;
        int n = -1;
        do{
            s = sc.nextLine();
            if(isInt(s)) {
                n = Integer.parseInt(s);
                if(n < 1 || n > max) n = -1;
            }
            valid =  n != -1 || (s.toLowerCase().equals("q"));
            if(!valid) System.out.println("Veuillez entrer un entier entre 1 et "+max+" pour choisir un niveau ou \"q\" pour revenir à l'écran titre");
        }while(!valid);
        return n;
    }

    //Asks the user his name
    public String askName(){
        System.out.println("Bonjour, quel est votre pseudo?");
        String name = sc.nextLine();
        return name;
    }

    //Closes the scanner
    public void close(){
        sc.close();
    }
}
