//A colored box that the player can destroy
public class ColoredBox extends Box{
    private int color;
    
    public ColoredBox(int c){
        super(c);
        color = c;
    }

    public int getColor(){
        return color;
    }

    public String toString(){
        return ""+color;
    }
}