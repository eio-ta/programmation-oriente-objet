import java.util.LinkedList;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;

//A level of the game
public class Level{
    //The grid that contains alll the boxes
    private Box[][] boxes;
    //The current score of the level
    private int score;
    //The number of turns the player is allowed to play in order to complete the level. If this value is -1, the number of turns is illimited
    private int turns;

    public Level(int nLevel){
        score = 0;
        loadLevel(nLevel);
    }

    public int charToInt(char c){
        if(c >= '0' && c <= '9') return c-'0';
        return c-'A'+10;
    }

    //Loads the level nLevel from a file
    public void loadLevel(int nLevel){
        File f = new File("../Levels/level"+nLevel+".txt");
        try{
            Scanner sc = new Scanner(f);
            turns = Integer.parseInt(sc.nextLine());
            LinkedList<String> lines = new LinkedList<String>();
            int height = 0;
            int ind = 0;
            //Stores the lines of the level file in a list
            while(sc.hasNextLine()){
                ind++;
                String line = sc.nextLine();
                if(line.length() != 0){
                    lines.add(line);
                } else {
                    height = ind-1;
                }
            }
            sc.close();
            boxes = new Box[height][lines.get(0).length()];
            //fills the board with the right box types and images indicated in the file
            for(int i = 0; i < height; i++){
                for(int j = 0; j < lines.get(i).length(); j++){
                    switch(lines.get(i).charAt(j)){
                        case 'p':
                            boxes[i][j] = new Pet(charToInt(lines.get(i+height).charAt(j)));
                            break;

                        case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':
                            boxes[i][j] = new ColoredBox(charToInt(lines.get(i).charAt(j)));
                            break;

                        case '#':case 'g':
                            boxes[i][j] = new Solid(charToInt(lines.get(i+height).charAt(j)), lines.get(i).charAt(j) == 'g');
                            break;

                        default:
                            boxes[i][j] = null;
                            break;
                    }
                }
            }
        } catch(FileNotFoundException e){
            System.out.println("The file: '../Levels/level"+nLevel+".txt' was not found");
        }
        
    }

    public Box[][] getBoxes(){
        return boxes;
    }

    public int getScore(){return score;}

    public int getTurns(){return turns;}

    public boolean isEmpty(int i, int j){
        return boxes[i][j] == null;
    }

    //Returns a list of the positions of the boxes of the same color around the position (i, j)
    public LinkedList<int[]> colorGroup(int i, int j){
        LinkedList<int[]> pos = new LinkedList<int[]>();
        if(!(boxes[i][j] instanceof ColoredBox)) return pos;
        int color = ((ColoredBox)boxes[i][j]).getColor();
        int[] p0 = {i, j};
        pos.add(p0);
        int index = 0;
        int[][] dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        while(index < pos.size()){
            for(int k = 0; k < 4; k++){
                int ii = pos.get(index)[0]+dirs[k][0];
                int jj = pos.get(index)[1]+dirs[k][1];
                if(ii >= 0 && ii < boxes.length && jj >= 0 && jj < boxes[0].length && !isEmpty(ii, jj)){
                    Box box = boxes[ii][jj];
                    if(box instanceof ColoredBox){
                        boolean alreadyInList = false;
                        for(int l = 0; l < pos.size(); l++){
                            int[] p = pos.get(l);
                            if(p[0] == ii && p[1] == jj) alreadyInList = true;
                        }
                        if(!alreadyInList && ((ColoredBox)box).getColor() == color){
                            int[] p = {ii, jj};
                            pos.add(p);
                        }
                    }
                }
            }
            index++;
        }
        return pos;
    }

    //Deletes the boxes at the positions stored int the list pos
    public void deleteBoxes(LinkedList<int[]> pos){
        for(int i = 0; i < pos.size(); i++){
            int[] p = pos.get(i);
            boxes[p[0]][p[1]].setMoveDestroy();
            boxes[p[0]][p[1]] = null;
        }
    }

    //Makes the boxes fall
    public void fall(){
        for(int i = boxes.length-1; i >= 0; i--){
            for(int j = 0; j < boxes[i].length; j++){
                if(!isEmpty(i, j) && !(boxes[i][j] instanceof Solid)){
                    int ii = i;
                    while(ii+1 < boxes.length && isEmpty(ii+1, j)){
                        boxes[ii][j].continueMove(ii+1, j);
                        boxes[ii+1][j] = boxes[ii][j];
                        boxes[ii][j] = null;
                        ii++;
                    }
                }
            }
        }
    }

    //Deletes the pets that are on the last row or on a solid box labeled as ground
    public boolean deletePets(){
        boolean petsDeleted = false;
        for(int j = 0; j < boxes[boxes.length-1].length; j++){
            if(boxes[boxes.length-1][j] instanceof Pet){
                boxes[boxes.length-1][j].addMoveDestroy();
                boxes[boxes.length-1][j] = null;
                score += 1000;
                petsDeleted = true;
            }
            //check if there is a pet on the row above the bottom on a "ground" labeled solid box
            if(boxes[boxes.length-2][j] instanceof Pet  && boxes[boxes.length-1][j] instanceof Solid && ((Solid)boxes[boxes.length-1][j]).isGround()){
                boxes[boxes.length-2][j].addMoveDestroy();
                boxes[boxes.length-2][j] = null;
                score += 1000;
                petsDeleted = true;
            }
        }
        return petsDeleted;
    }

    //Moves to the left the columns of boxes that are on top of a solid box (or on the last row) and have nothing to their left
    public boolean moveToLeft(){
        boolean b=false;
        for(int j=1;j<boxes[0].length;j++){
            int filledBox = 0;
            for(int i=boxes.length-1;i>=0;i--){
                if((boxes[i][j] instanceof ColoredBox || boxes[i][j] instanceof Pet) && isEmpty(i, j-1)){
                    filledBox++;
                } else {
                    if(filledBox != 0){
                        for(int a=0;a<filledBox;a++){
                            boxes[i+filledBox-a][j].continueMove(i+filledBox-a, j-1);
                            boxes[i+filledBox-a][j-1] = boxes[i+filledBox-a][j];
                            boxes[i+filledBox-a][j] = null;
                        }
                        filledBox=0;
                        b=true;  
                    }
                    while(!(boxes[i][j] instanceof Solid) && i>0){
                        i--;
                    }
                }
            }
            if(filledBox != 0){
                for(int a=0;a<filledBox;a++){
                    boxes[filledBox-1-a][j].continueMove(filledBox-1-a, j-1);
                    boxes[filledBox-1-a][j-1] = boxes[filledBox-1-a][j];
                    boxes[filledBox-1-a][j] = null;
                }
                b=true;
            }
            if(b) return true;
        }
        return false;
    }


    //Deletes all remaining color groups and adds bonus points for each color group
    public void bonusPoint(){
        if(isWon()){
            int max=0;
            do{
                max  = 0;
                int posI = -1;
                int posJ= -1;
                for(int k =0; k<boxes.length;k++){
                    for(int l= 0; l<boxes[k].length;l++){
                        LinkedList<int[]> group = colorGroup(k, l);
                        if(group.size()>max){
                            max=group.size();
                            posI=k;
                            posJ=l;
                        }
                    }
                }
                playTurn(posI, posJ);
            }while(max>1);
        }    
    }

    
    //Players win when there is no more pets in the level
    public boolean isWon(){
        for(int i=0;i<this.boxes.length;i++){
            for(int j=0;j<this.boxes[i].length;j++){
                if(this.boxes[i][j]instanceof Pet) return false;
            }
        }
        return true;
    }

    //Players lose when their number of turns == 0 or if they can't clic on any boxes
    public boolean isLost(){
        if(this.isWon()) return false;
        if (this.turns==0) return true;
        for(int i=0;i<this.boxes.length;i++){
            for(int j=0;j<this.boxes[i].length;j++){
                if(!isEmpty(i, j) && boxes[i][j] instanceof ColoredBox && colorGroup(i, j).size() > 1) return false;
            }
        }
        return true;
    }


    //Plays a turn at the position (i,j)
    //It returns a list of the evolution of the score during the turn. This list is used when animating the turn in order to change the score display at the right time
    public LinkedList<Integer> playTurn(int i, int j){
        LinkedList<Integer> scorePerMove = new LinkedList<>();
        //Checks if the position is valid
        if(i >= 0 && i < boxes.length && j >= 0 && j < boxes[i].length && !isEmpty(i, j) && boxes[i][j] instanceof ColoredBox){
            LinkedList<int[]> group = colorGroup(i, j);
            if(group.size() > 1){
                for(int k = 0; k < this.boxes.length; k++){
                    for(int l = 0; l < this.boxes[k].length; l++){
                        if(!isEmpty(k, l)){
                            boxes[k][l].clearMoves();
                            boxes[k][l].addMove(k, l, k, l);
                        }
                    }
                }
                score += group.size()*group.size()*10;
                scorePerMove.add(score);
                deleteBoxes(group);
                boolean moved;
                do{
                    fall();
                    boolean movedToLeft = moveToLeft();//the order moveToLeft then deletePets is important: if we delete the pets first it could cause "bugs" because boxes could slide under boxes that haven't fallen yet
                    boolean petsDeleted = deletePets();
                    moved = movedToLeft || petsDeleted;
                    if(petsDeleted){//If a pet has been deleted, add another move to all the boxes
                        scorePerMove.add(score);
                        for(int k = 0; k < this.boxes.length; k++){
                            for(int l = 0; l < this.boxes[k].length; l++){
                                if(!isEmpty(k, l)){
                                    if(boxes[k][l].getMoves().getLast()[0][0] == -1){
                                        boxes[k][l].addMove(-1, -1, -1, -1);
                                    } else {
                                        boxes[k][l].addMove(k, l, k, l);
                                    }
                                    
                                }
                            }
                        }
                    }
                }while(moved);
                if(turns != -1) turns--;
            }
        }
        return scorePerMove;
    }
}
