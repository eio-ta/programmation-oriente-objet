import java.lang.Thread;


/* This robot plays all the levels and quits the game
 it also stops if he looses a level
*/
public class Robot extends Player{
    private boolean finishedPlaying;
    private int lastLevel;

    public Robot(){
        super();
        finishedPlaying = false;
        lastLevel = 0;
    }

    //Slows down the robot
    public void think(){
        try{
            System.out.println("Le robot réfléchit...");
            Thread.sleep(1000);
        } catch(InterruptedException e){
            e.printStackTrace();
        }
    }

    //Returns the number of the next level if there is one else return -1
    public int chooseLevel(int max){
        think();
        return finishedPlaying ? -1 : max;
    }

    /*Searches if the proposition next, play, quit and retry exists
    Returns play if he can't next and quit
    Returns next if he can next
    Returns return if he can't quit and finish to play
    Returns quit if he finishes to play and can quit
    */
    public  String choosePlay(String[] propositions){
        think();
        boolean canNext = false;
        boolean canPlay = false;
        boolean canQuit = false;
        boolean canRetry = false;
        for(int i = 0; i < propositions.length; i++){
            if(propositions[i].equals("next")) canNext = true;
            if(propositions[i].equals("play")) canPlay = true;
            if(propositions[i].equals("q")) canQuit = true;
            if(propositions[i].equals("retry")) canRetry = true;
        }
        if(canPlay && !canNext && !canRetry && !canQuit) finishedPlaying = true;
        if(canPlay && !canNext && !finishedPlaying) return "play";
        if(canNext) return "next";
        if(finishedPlaying && !canQuit) return "return";
        return "q";
    }

    //Returns a random position of the level taken
    public int[] choosePos(Level level){
        think();
        Box[][] board = level.getBoxes();
        int h = board.length;
        int w = board[0].length;
        
        int[] pos = new int[2];
        int n = 0;
        do{
            pos[0] = (int)(Math.random()*h);
            pos[1] = (int)(Math.random()*w);
            n = level.colorGroup(pos[0], pos[1]).size();
        }while(n < 2);
        return pos;
    }

    //Returns robot as its name
    public String chooseName(){
        return "robot";
    }

}
