import javax.swing.*;
import javax.imageio.*;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.border.EmptyBorder;

//Manages the view of the game in a Graphical User Interface
public class GraphicView extends GeneralView{
    private View view;
    public GraphicView(Player player){
        super(player);
        view = new View();
        view.setVisible(true);
    }

    //The window of the game
    class View extends JFrame{
        private ScreenTitle screenTitle;
        private ScreenLogin screenLogin;
        private ScreenLevelsMenu screenLevelsMenu;
        private ScreenLevel screenLevel;
        private ScreenLevelEnd screenLevelEnd;
        //The background color
        private final Color bgColor = new Color(105, 190, 201);
        //The font used for every text in the game
        private Font font;

        public View(){
            //Load the font
            try {
                GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
                ge.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("..//Fonts/rainyhearts.ttf")));
                font = new Font("rainyhearts", Font.PLAIN, 64);
            } catch (IOException|FontFormatException e) {
                e.printStackTrace();
            }


            //Initializes the window
            setSize(850, 750);
            setLocationRelativeTo(null);
            setResizable(false);
            setTitle("Pet Rescue");
            setDefaultCloseOperation(EXIT_ON_CLOSE);


            //Uses a cardLayout and adds all the different screens to it
            getContentPane().setLayout(new CardLayout());

            screenTitle = new ScreenTitle();
            getContentPane().add(screenTitle, "title");

            screenLogin = new ScreenLogin();
            getContentPane().add(screenLogin, "login");

            screenLevelsMenu = new ScreenLevelsMenu();
            getContentPane().add(screenLevelsMenu, "levelsMenu");

            screenLevel = new ScreenLevel();
            getContentPane().add(screenLevel, "level");

            screenLevelEnd = new ScreenLevelEnd();
            getContentPane().add(screenLevelEnd, "levelEnd");


            //The game starts on the title screen
            changeScreen("title");

        }

        //The title screen
        class ScreenTitle extends JPanel{
            private JPanel logo, loadingGame;
            private JLabel label;
            private JButton play;
            private BufferedImage imageTitle;

            public ScreenTitle(){
                try{
                    imageTitle = ImageIO.read(new File("../Images/title.png"));
                }catch(IOException e){
                    System.out.println("Title image not found");
                }
                this.setLayout(new GridLayout(2,1));
                
                logo = new JPanel(new BorderLayout());             
                label = new JLabel(new ImageIcon((new ImageIcon(imageTitle)).getImage().getScaledInstance(134*4, 28*4, Image.SCALE_DEFAULT)));
                logo.add(label, BorderLayout.CENTER);

                loadingGame = new JPanel();
                loadingGame.setLayout(new BorderLayout());        
                play = new JButton(new ImageIcon(new ImageIcon("../Images/playButton.png").getImage().getScaledInstance(30*4, 18*4, Image.SCALE_DEFAULT)));
                play.setBorder(null);
                play.setBorderPainted(false);
                play.setMargin(new Insets(0, 0, 0, 0));
                play.setContentAreaFilled(false);
                play.addActionListener((ActionEvent e)->{
                    changeScreen("login");
                });
                loadingGame.add(play,BorderLayout.NORTH);


                this.add(logo);
                this.add(loadingGame);
                logo.setBackground(bgColor);
                loadingGame.setBackground(bgColor);   
            }
        }

        //The login screen
        class ScreenLogin extends JPanel{
            private JPanel textPanel;
            private JTextField text;
            private JButton login;
            private JLabel title;

            ScreenLogin(){
                setBackground(bgColor);

                textPanel = new JPanel(new GridLayout(2, 1));
                textPanel.setBackground(bgColor);
                text = new JTextField("",20);
                text.setFont(font);
                text.setHorizontalAlignment(SwingConstants.CENTER);
                text.setSize(new Dimension(6, 3));
                textPanel.add(text);

                login = new JButton(new ImageIcon(new ImageIcon("../Images/playButton.png").getImage().getScaledInstance(30*4, 18*4, Image.SCALE_DEFAULT)));
                login.setBorder(null);
                login.setBorderPainted(false);
                login.setMargin(new Insets(0, 0, 0, 0));
                login.setContentAreaFilled(false);
                login.addActionListener((ActionEvent e)->{
                    name = text.getText();
                    if(!name.equals("")){
                        if(!player.load(name)){
                            if(player instanceof Human){
                                player = new Human();
                            }else{
                                player= new Robot();
                            }
                            
                        }
                        screenLevelsMenu.setAccessibleLevels();
                        changeScreen("levelsMenu");
                    }
                });   
                
                
                textPanel.add(login);

                title = new JLabel("Votre pseudo:");
                title.setFont(font);
                title.setHorizontalAlignment(SwingConstants.CENTER);

                setLayout(new GridLayout(3,1));
                add(title);
                add(textPanel);
                
            }
        }

        //The level selection screen
        class ScreenLevelsMenu extends JPanel{
            private JButton quit;
            private JPanel navigationButtons, titleAndButtons, levelButtonsPanel;
            private JLabel title;
            private JButton[] levelButtons;
            
            public ScreenLevelsMenu(){

                setLayout(new BorderLayout());

                navigationButtons = new JPanel(new BorderLayout());
                navigationButtons.setBackground(bgColor);

                quit = new JButton(new ImageIcon(new ImageIcon("../Images/return.png").getImage().getScaledInstance(16*4, 10*4, Image.SCALE_DEFAULT)));
                quit.setHorizontalTextPosition(SwingConstants.CENTER);
                quit.setBorder(new EmptyBorder(0, 15, 15, 0));
                quit.setBorderPainted(false);
                quit.setMargin(new Insets(0, 0, 0, 0));
                quit.setContentAreaFilled(false);
                quit.addActionListener((ActionEvent e) -> {
                    changeScreen("title");
                });
                navigationButtons.add(quit, BorderLayout.LINE_START);

                add(navigationButtons, BorderLayout.PAGE_END);


                titleAndButtons = new JPanel();
                titleAndButtons.setLayout(new BoxLayout(titleAndButtons, BoxLayout.Y_AXIS));
                titleAndButtons.setBackground(bgColor);

                title = new JLabel("Niveaux");
                title.setAlignmentX(JLabel.CENTER_ALIGNMENT);
                title.setFont(font);
                title.setBorder(new EmptyBorder(15,0,15,0));
                titleAndButtons.add(title);


                levelButtonsPanel = new JPanel(new GridLayout(0, 8));
                levelButtonsPanel.setBorder(new EmptyBorder(0,15,0,15));
                levelButtonsPanel.setBackground(bgColor);

                levelButtons = new JButton[GraphicView.this.nLevels];
                //Creates all the buttons to access the levels
                for(int i = 0; i < levelButtons.length; i++){
                    final int level = i+1;
                    levelButtons[i] = new JButton(Integer.toString(level), new ImageIcon(new ImageIcon("../Images/levelButton.png").getImage().getScaledInstance(16*4, 16*4, Image.SCALE_DEFAULT)));
                    levelButtons[i].setFont(font);
                    levelButtons[i].setHorizontalTextPosition(SwingConstants.CENTER);
                    levelButtons[i].setBorder(null);
                    levelButtons[i].setBorderPainted(false);
                    levelButtons[i].setMargin(new Insets(0, 0, 0, 0));
                    levelButtons[i].setContentAreaFilled(false);
                    levelButtons[i].addActionListener((ActionEvent e) -> {
                        currentLevel = level;
                        screenLevel.loadLevel();
                        changeScreen("level");
                    });
                    levelButtonsPanel.add(levelButtons[i]);
                }
                //I add empty JPanels in the grid to prevent cells to stretch vertically
                for(int i = levelButtons.length; i < 40; i++){
                    JPanel p = new JPanel();
                    p.setBackground(bgColor);
                    levelButtonsPanel.add(p);
                }

                titleAndButtons.add(levelButtonsPanel);

                add(titleAndButtons);

                setAccessibleLevels();
            }

            //Updates the levels that are locked or unlocked depending on the progression of the player
            public void setAccessibleLevels(){
                for(int i = 0; i < levelButtons.length; i++){
                    levelButtons[i].setEnabled(i < GraphicView.this.player.getMaxLevel());
                }
            }
        }

        //The screen in which the player plays a level
        class ScreenLevel extends JPanel{
            private Level level;
            private LevelPanel levelPanel;
            private JButton returnToLevelsMenu, restart;
            private JLabel score, turns, currentLevelLabel;
            private JPanel text, navigation;

            public ScreenLevel(){
                text = new JPanel();
                text.setLayout(new BorderLayout());
                text.setBackground(bgColor);

                levelPanel = new LevelPanel();   

                navigation = new JPanel(new BorderLayout());
                navigation.setBackground(bgColor);

                returnToLevelsMenu = new JButton(new ImageIcon(new ImageIcon("../Images/return.png").getImage().getScaledInstance(16*4, 10*4, Image.SCALE_DEFAULT)));
                returnToLevelsMenu.setBorder(new EmptyBorder(0, 15, 15, 0));
                returnToLevelsMenu.setBorderPainted(false);
                returnToLevelsMenu.setMargin(new Insets(0, 0, 0, 0));
                returnToLevelsMenu.setContentAreaFilled(false);
                returnToLevelsMenu.addActionListener((ActionEvent e)->{
                    changeScreen("levelsMenu");
                });
                navigation.add(returnToLevelsMenu, BorderLayout.LINE_START);

                currentLevelLabel = new JLabel();
                currentLevelLabel.setFont(font);
                currentLevelLabel.setHorizontalAlignment(SwingConstants.CENTER);
                navigation.add(currentLevelLabel, BorderLayout.CENTER);

                restart = new JButton(new ImageIcon(new ImageIcon("../Images/restart.png").getImage().getScaledInstance(10*4, 10*4, Image.SCALE_DEFAULT)));
                restart.setBorder(new EmptyBorder(0, 0, 15, 15));
                restart.setBorderPainted(false);
                restart.setMargin(new Insets(0, 0, 0, 0));
                restart.setContentAreaFilled(false);
                restart.addActionListener((ActionEvent e)->{
                    loadLevel();
                    levelPanel.animate = false;
                    repaint();
                });
                navigation.add(restart, BorderLayout.LINE_END);

                score=new JLabel("Score: ");
                score.setFont(font);
                score.setHorizontalAlignment(SwingConstants.CENTER);
                text.add(score, BorderLayout.CENTER);

                turns = new JLabel();
                turns.setFont(font);
                turns.setBorder(new EmptyBorder(0, 0, 0, 15));
                text.add(turns, BorderLayout.LINE_END);

                
                setLayout(new BorderLayout());
                add(text, BorderLayout.NORTH);
                add(levelPanel, BorderLayout.CENTER);
                add(navigation, BorderLayout.SOUTH);          
            }

            //Fisher-Yates array shuffle Algorithm
            public void shuffleImages(Image[] images){
                for(int i = images.length-1; i > 0; i--){
                    int j = (int)(Math.random()*(i+1));
                    Image tmp = images[i];
                    images[i] = images[j];
                    images[j] = tmp;
                }
            }

            //Initializes the current level
            public void loadLevel(){
                level = new Level(currentLevel);
                shuffleImages(levelPanel.coloredBoxImages);
                shuffleImages(levelPanel.petImages);
                score.setText("Score: "+level.getScore());
                turns.setText(level.getTurns() != -1 ? "Tours restants: "+level.getTurns() : "");
                currentLevelLabel.setText("Niveau "+currentLevel);
            }

            //Plays a turn at the position (i, j) and plays the animation of the turn
            public void playTurn(int i, int j){
                //Stores the boxes before the turn is played so it can animate all the boxes, even those which are deleted during the turn
                Box[][] boxes = level.getBoxes();
                Box[][] lastBoxes = new Box[boxes.length][];
                for(int ind = 0; ind < boxes.length; ind++) lastBoxes[ind] = boxes[ind].clone();
                
                LinkedList<Integer> scorePerMove = level.playTurn(i, j);
                if(scorePerMove.size() > 0){
                    if(level.getTurns() != -1) turns.setText("Tours restants: "+level.getTurns());
                    levelPanel.lastBoxes = lastBoxes;
                    levelPanel.animate = true;
                    levelPanel.nMove = 0;
                    levelPanel.animationTime = 0;
                    score.setText("Score: "+scorePerMove.get(levelPanel.nMove));

                    //The timer is called at a regular interval to animate the moves that occured during the turn and it stops itself when the animation is over
                    Timer timer = new Timer((int)(1000*levelPanel.timePerFrame), new ActionListener(){
                        public void actionPerformed(ActionEvent evt){
                            //Stops the animation if the player changes screen or resets the level
                            if(!screen.equals("level") || !levelPanel.animate){
                                levelPanel.animate = false;
                                ((Timer)evt.getSource()).stop();
                                return;
                            }
                            //Draws the current state of the animation
                            levelPanel.repaint();

                            levelPanel.animationTime += levelPanel.timePerFrame;
                            if(levelPanel.animationTime >= levelPanel.timePerMove || levelPanel.isMoveEnded()){
                                levelPanel.nMove++;
                                if(levelPanel.nMove >= scorePerMove.size()){
                                    if(level.isWon()){//If the level is won, delete all remaining groups and go to the end level screen
                                        int posI = -1;
                                        int posJ = -1;
                                        int max = 0;
                                        for(int k=0;k<boxes.length;k++){
                                            for(int l=0;l<boxes[k].length;l++){
                                                if(boxes[k][l] instanceof ColoredBox){
                                                    LinkedList<int[]> group = level.colorGroup(k, l);
                                                    if(group.size() > max){
                                                        posI = k;
                                                        posJ = l;
                                                        max = group.size();
                                                    }
                                                }
                                            }
                                        }
                                        if(max > 1){
                                            Box[][] boxes = level.getBoxes();
                                            Box[][] lastBoxes = new Box[boxes.length][];
                                            for(int ind = 0; ind < boxes.length; ind++) lastBoxes[ind] = boxes[ind].clone();
                                            levelPanel.lastBoxes = lastBoxes;


                                            LinkedList<Integer> scorePerMov = level.playTurn(posI, posJ);
                                            scorePerMove.clear();
                                            scorePerMove.addAll(scorePerMov);

                                            levelPanel.nMove = 0;
                                            levelPanel.animationTime = 0;
                                            score.setText("Score: "+scorePerMove.get(levelPanel.nMove));
                                        } else {
                                            levelPanel.animate = false;
                                            screenLevelEnd.init(true, level.getScore());
                                            changeScreen("levelEnd");
                                            player.save(name);
                                            ((Timer)evt.getSource()).stop();
                                        }
                                    } else {
                                        if(level.isLost()){
                                            screenLevelEnd.init(false, level.getScore());
                                            changeScreen("levelEnd");
                                        }
                                        levelPanel.animate = false;
                                        ((Timer)evt.getSource()).stop();
                                    }

                                } else {
                                    score.setText("Score: "+scorePerMove.get(levelPanel.nMove));
                                    levelPanel.animationTime = 0;
                                }
                            }
                        }
                    });
                    timer.start();
                }
            }
           
            class LevelPanel extends JPanel{
                private BufferedImage[] coloredBoxImages;
                private BufferedImage[] petImages;
                private BufferedImage[] solidImages;
                // The current time of the animation in seconds
                private double animationTime;
                private final double timePerFrame = 1./30.;// In seconds
                // The maximum time a move animation takes
                private final double timePerMove = 1;
                //The state of the board before the last turn occured
                private Box[][] lastBoxes;
                //If true, displays an animation from the state of the board before the last turn to the current state of the board
                private boolean animate;
                //The current move that is being animated
                private int nMove;

                public LevelPanel(){
                    animate = false;
                    setBackground(bgColor);
                    coloredBoxImages = new BufferedImage[10];
                    try{
                        for(int i = 0; i < coloredBoxImages.length; i++) coloredBoxImages[i] = ImageIO.read(new File("../Images/ColoredBoxes/coloredBox"+i+".png"));
                    } catch (Exception e){
                        e.printStackTrace();
                    }

                    petImages = new BufferedImage[2];
                    try{
                        for(int i = 0; i < petImages.length; i++) petImages[i] = ImageIO.read(new File("../Images/Pets/pet"+i+".png"));
                    } catch (Exception e){
                        e.printStackTrace();
                    }

                    solidImages = new BufferedImage[21];
                    try{
                        for(int i = 0; i < solidImages.length; i++) solidImages[i] = ImageIO.read(new File("../Images/Solids/solid"+i+".png"));
                    } catch (Exception e){
                        e.printStackTrace();
                    }

                    //When a click occurs on this panel, calculates which box the mouse clicked on and plays a turn on this box
                    addMouseListener(new MouseAdapter(){
                        @Override
                        public void mouseReleased(MouseEvent e){
                            int x = getWidth()/2-level.getBoxes()[0].length*64/2;
                            int y = getHeight()/2-level.getBoxes().length*64/2;
                            int i = ((e.getY()-y)/64);
                            int j = ((e.getX()-x)/64);
                            if(!levelPanel.animate) playTurn(i, j);
                        }
                    });
                }

                //Displays the level
                public void displayLevel(int x, int y, int squareSize, Graphics g){
                    Box[][] boxes = level.getBoxes();
                    for(int i = 0; i < boxes.length; i++){
                        for(int j = 0; j < boxes[i].length; j++){
                            if(!level.isEmpty(i, j)){
                                if(boxes[i][j] instanceof Pet){
                                    g.drawImage(petImages[boxes[i][j].getImageIndex()], x+j*squareSize, y+i*squareSize, squareSize, squareSize, null);
                                } else if(boxes[i][j] instanceof ColoredBox){
                                    g.drawImage(coloredBoxImages[((ColoredBox)boxes[i][j]).getColor()], x+j*squareSize, y+i*squareSize, squareSize, squareSize, null);
                                } else if(boxes[i][j] instanceof Solid){
                                    g.drawImage(solidImages[boxes[i][j].getImageIndex()], x+j*squareSize, y+i*squareSize, squareSize, squareSize, null);
                                }
                            }
                        }
                    }
                }

                //Returns if the animation of the move is ended
                public boolean isMoveEnded(){
                    Box[][] boxes = lastBoxes;
                    double t = animationTime/timePerMove;
                    for(int i = 0; i < boxes.length; i++){
                        for(int j = 0; j < boxes[i].length; j++){
                            if(boxes[i][j] != null && !(boxes[i][j] instanceof Solid) && nMove < boxes[i][j].getMoves().size()){
                                int[][] move = boxes[i][j].getMoves().get(nMove);
                                if(move[0][0] != -1){
                                    if(1.5*(3*t*t-2*t*t*t) < 1 || 7*t*t < move[1][0]-move[0][0]) return false;
                                }
                            }
                        }
                    }
                    return true;
                }

                //Displays the level transitioning from the start of a move to the end of a move
                public void displayLevelAnimation(int x, int y, int squareSize, Graphics g){
                    Box[][] boxes = lastBoxes;

                    // We draw first the solid boxes
                    for(int i = 0; i < boxes.length; i++){
                        for(int j = 0; j < boxes[i].length; j++){
                            if(boxes[i][j] instanceof Solid){
                                g.drawImage(solidImages[boxes[i][j].getImageIndex()], x+j*squareSize, y+i*squareSize, squareSize, squareSize, null);
                            }
                        }
                    }

                    double t = animationTime/timePerMove;
                    for(int i = 0; i < boxes.length; i++){
                        for(int j = 0; j < boxes[i].length; j++){
                            if(boxes[i][j] != null && !(boxes[i][j] instanceof Solid) && nMove < boxes[i][j].getMoves().size()){
                                int[][] move = boxes[i][j].getMoves().get(nMove);
                                if(move[0][0] != -1){// -1 means that the box has been destroyed
                                    //The block x position is interpolated with the smoothstep function and the y position follows a fall trajectory
                                    int boxX = x+move[0][1]*squareSize+(int)(((move[1][1]-move[0][1])*squareSize)*Math.min(1.5*(3*t*t-2*t*t*t), 1));
                                    int boxY = y+move[0][0]*squareSize+(int)(Math.min(7*squareSize*t*t, (move[1][0]-move[0][0])*squareSize));
                                    if(boxes[i][j] instanceof Pet){
                                        g.drawImage(petImages[boxes[i][j].getImageIndex()], boxX, boxY, squareSize, squareSize, null);
                                    } else if(boxes[i][j] instanceof ColoredBox){
                                        g.drawImage(coloredBoxImages[((ColoredBox)boxes[i][j]).getColor()], boxX, boxY, squareSize, squareSize, null);
                                    } else if(boxes[i][j] instanceof Solid){
                                        g.drawImage(solidImages[boxes[i][j].getImageIndex()], boxX, boxY, squareSize, squareSize, null);
                                    }
                                }
                            }
                        }
                    }
                }

                //Displays the level at the center of the panel with each box measuring 64*64 pixels
                public void paintComponent(Graphics g){
                    super.paintComponent(g);
                    int s = 64;
                    int x = getWidth()/2-level.getBoxes()[0].length*s/2;
                    int y = getHeight()/2-level.getBoxes().length*s/2;
                    if(!animate){
                        displayLevel(x, y, s, g);        
                    } else {
                        displayLevelAnimation(x, y, s, g);
                    }
                }
            }

        }

        //The screen showed when a level is won or lost
        class ScreenLevelEnd extends JPanel{
            JPanel mainPanel, messagePanel, victoryOrDefeatPanel, scoreMessagePanel, choicePanel, navigationPanel;
            JButton restartButton, nextButton, returnButton;
            JLabel message, scoreMessage, bestScoreMessage;

            public ScreenLevelEnd(){
                setBackground(bgColor);
                messagePanel = new JPanel(new GridLayout(2,1));
                messagePanel.setBackground(bgColor);

                victoryOrDefeatPanel = new JPanel();
                victoryOrDefeatPanel.setBackground(bgColor);
                message = new JLabel();
                message.setFont(font);
                message.setBorder(new EmptyBorder(15, 0, 0, 0));
                victoryOrDefeatPanel.add(message, BorderLayout.CENTER);

                scoreMessagePanel = new JPanel(new GridLayout(2,1));
                scoreMessagePanel.setBackground(bgColor);
                scoreMessage = new JLabel();
                scoreMessage.setFont(font);
                scoreMessage.setHorizontalAlignment(SwingConstants.CENTER);
                bestScoreMessage = new JLabel();
                bestScoreMessage.setFont(font);
                bestScoreMessage.setHorizontalAlignment(SwingConstants.CENTER);

                scoreMessagePanel.add(scoreMessage);
                scoreMessagePanel.add(bestScoreMessage);

                messagePanel.add(victoryOrDefeatPanel);
                messagePanel.add(scoreMessagePanel);   


                choicePanel = new JPanel(new FlowLayout());
                choicePanel.setBackground(bgColor);
                restartButton = new JButton(new ImageIcon(new ImageIcon("../Images/restart.png").getImage().getScaledInstance(10*4, 10*4, Image.SCALE_DEFAULT)));
                restartButton.setBorder(null);
                restartButton.setBorderPainted(false);
                restartButton.setMargin(new Insets(0, 0, 0, 0));
                restartButton.setContentAreaFilled(false);
                restartButton.addActionListener((ActionEvent e)->{
                    screenLevel.loadLevel();
                    changeScreen("level");
                });
                choicePanel.add(restartButton);

                nextButton = new JButton(new ImageIcon(new ImageIcon("../Images/next.png").getImage().getScaledInstance(16*4, 10*4, Image.SCALE_DEFAULT)));
                nextButton.setBorder(new EmptyBorder(0, 15, 0, 0));
                nextButton.setBorderPainted(false);
                nextButton.setMargin(new Insets(0, 0, 0, 0));
                nextButton.setContentAreaFilled(false);
                nextButton.addActionListener((ActionEvent e)->{
                    currentLevel++;
                    screenLevel.loadLevel();
                    changeScreen("level");
                });
                
                choicePanel.add(nextButton);

                navigationPanel = new JPanel(new BorderLayout());
                navigationPanel.setBackground(bgColor);
                returnButton = new JButton(new ImageIcon(new ImageIcon("../Images/return.png").getImage().getScaledInstance(16*4, 10*4, Image.SCALE_DEFAULT)));
                returnButton.setBorder(new EmptyBorder(0, 15, 15, 0));
                returnButton.setBorderPainted(false);
                returnButton.setMargin(new Insets(0, 0, 0, 0));
                returnButton.setContentAreaFilled(false);
                returnButton.addActionListener((ActionEvent e)->{
                    changeScreen("levelsMenu");
                });
                navigationPanel.add(returnButton, BorderLayout.LINE_START);

                mainPanel = new JPanel(new GridLayout(2,1));
                mainPanel.setBackground(bgColor);
                mainPanel.add(messagePanel);
                mainPanel.add(choicePanel);

                setLayout(new BorderLayout());
                add(mainPanel, BorderLayout.CENTER);
                add(navigationPanel, BorderLayout.SOUTH);
            }

            //Initializes the screen
            public void init(boolean isWon, int score){
                if(isWon){
                    if(currentLevel>player.getScores().size()){
                        player.getScores().add(score);
                    }else{
                        if(screenLevel.level.getScore()>player.getScores().get(currentLevel-1)){
                            player.getScores().set(currentLevel-1, score);
                        }
                    }
                    scoreMessage.setText("Score: "+score);
                    bestScoreMessage.setText("Meilleur score: "+player.getScores().get(currentLevel-1));
                    if(currentLevel+1 > player.getMaxLevel() && currentLevel<nLevels){
                        player.setMaxLevel(currentLevel+1);
                        screenLevelsMenu.levelButtons[player.getMaxLevel()-1].setEnabled(true);
                    }                   
                }else{
                    scoreMessage.setText("");
                    bestScoreMessage.setText(player.getScores().size()>=currentLevel ? "Meilleur score: "+player.getScores().get(currentLevel-1) : "");                   
                }
                nextButton.setEnabled(currentLevel<player.getMaxLevel() && isWon);
                message.setText(isWon?"Bravo, vous avez gagné !":"Vous avez perdu");

            }
        }

        //Changes the current screen
        public void changeScreen(String screen){
            GraphicView.this.screen = screen;
            ((CardLayout)(getContentPane().getLayout())).show(getContentPane(), screen);
        }        

    }
    
}
