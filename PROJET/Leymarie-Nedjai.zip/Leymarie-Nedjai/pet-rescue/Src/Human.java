/* This class interracts with a human player
 */

public class Human extends Player{
    private Communication com;

    public Human(){
        super();
        com = new Communication();
    }

    //Closes the scanner from communication
    public void closeCommunication(){
        com.close();
    }

    /* Takes player's maxLevel in parameters
    Returns an integer with player's choice level
    */
    public int chooseLevel(int max){
        return com.askLevel(max);
    }

    /* Takes all expected String in an array of String
    Returns the String that the player chooses
    */
    public  String choosePlay(String[] propositions){
        return com.askPlay(propositions);
    }

    /* Takes a level in parameter
    Returns an array of integer of the position of a block
    */
    public int[] choosePos(Level level){
        return com.askPos();
    }

    /* Returns the name of the user
     */
    public String chooseName(){
        return com.askName();
    }
}
