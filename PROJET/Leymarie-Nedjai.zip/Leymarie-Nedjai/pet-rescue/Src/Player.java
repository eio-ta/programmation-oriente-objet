import java.lang.ClassNotFoundException;
import java.util.ArrayList;
import java.io.*;

// This class stores a player's best scores and progression, and manages its interactions with the game
public abstract class Player {
    private int maxLevel;
    private ArrayList<Integer> scores;

    public Player(){
        maxLevel = 1;
        scores = new ArrayList<Integer>();
    }

    //Returns player's progression
    public int getMaxLevel(){
        return maxLevel;
    }

    //Changes player's progression
    public void setMaxLevel(int n){
        maxLevel = n;
    }

    //Returns player's best scores
    public ArrayList<Integer> getScores(){
        return scores;
    }

    /*Loads player's progression and best scores from a .ser file
    Returns false if the file doesn't exist
    */
    @SuppressWarnings("unchecked")
    public boolean load(String name){
        File file = new File("../Saves/"+name+".ser");
        if(!(file.exists())){return false;}
        
        try{
            ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(file));
            this.maxLevel=objectInputStream.readInt();
            this.scores =(ArrayList<Integer>) objectInputStream.readObject();
            objectInputStream.close(); 
        }catch(IOException | ClassNotFoundException e){
            e.printStackTrace();
        }
        return true;
        
     
    }

    //Saves player's progression and best scores in a .ser file
    public void save(String name){        
        try{
            File file = new File("../Saves/"+name+".ser");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(file));
            objectOutputStream.writeInt(maxLevel);
            objectOutputStream.writeObject(scores);
            objectOutputStream.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    /* Takes player's maxLevel in parameters
    Returns an integer with player's choice level
    */
    public abstract int chooseLevel(int max);

    /* Takes all expected String in an array of String
    Returns the String that the player chooses
    */
    public abstract String choosePlay(String[] propositions);

    /* Takes a level in parameter
    Returns an array of integer of the position of a block
    */
    public abstract int[] choosePos(Level level);

    /* Returns the name of the user
     */
    public abstract String chooseName();

}
