import java.util.ArrayList;
import java.lang.ClassNotFoundException;
import java.io.*;

//This class interracts with the player and displays the game in the terminal

public class TerminalView extends GeneralView{
    private String name;

    public TerminalView(Player player){
        super(player);
    }

    //Switches between the different screens
    public void play(){
        do{
            switch(screen){
                case "screenTitle": screenTitle(); break;
                case "loginScreen": loginScreen();break;
                case "levelsMenu": levelsMenu(); break;
                case "screenLevel": screenLevel(); break;
            }
        }while(!screen.equals("quit"));
    }

    //Displays the title of the game
    public void screenTitle(){
        for(int i=0;i<35;i++)System.out.print("#");

        System.out.print("\n#");
        for(int i=0;i<33;i++)System.out.print(" ");
        System.out.println("#");

        System.out.println("#   ~Bienvenue dans Pet Rescue~   #");
        System.out.println("#  Un jeu d'Alexandre et Etienne  #");

        System.out.print("#");
        for(int i=0;i<33;i++)System.out.print(" ");
        System.out.println("#");

        for(int i=0;i<35;i++)System.out.print("#");
        System.out.println("\n");



        System.out.println("Appuyer sur \"j\" pour jouer ou \"q\" pour quitter");
        String[] proposition = {"jouer","play","quitter","j","q"};
        String choice=player.choosePlay(proposition);
        if(choice.equals("j")||choice.equals("jouer")||choice.equals("play")){
            screen = "loginScreen";
        } else {
            screen = "quit";
        }
    }

    /*Asks player's name
    If it exists, it loads his saves
    Else it creates a new player
     */
    public void loginScreen(){
        name = player.chooseName();
        if(!player.load(name)){
            if(player instanceof Human){
                player = new Human();
            }else{
               player = new Robot();
            }
            
        }
        screen = "levelsMenu";
    }

    /* Displays the levels and the best score next to them
        The player can't choose unlock level
     */
    public void levelsMenu(){
        int max = player.getMaxLevel();
        ArrayList<Integer> scores = player.getScores();

        System.out.println("Choisissez un niveau:");
        for(int i = 1; i <= nLevels; i++){
            System.out.print("Niveau "+i);
            if(i > max){
                System.out.println(" (pas encore débloqué)");
            } else {
                System.out.println((i-1<scores.size() ? ", meilleur score: "+scores.get(i-1) : ""));
            }
        }
        System.out.println("Entrez un entier entre 1 et "+max+" pour choisir un niveau ou 'q' pour revenir à l'écran titre");
        int n = player.chooseLevel(max);
        if(n == -1){
            screen = "screenTitle";
        } else {
            System.out.println("Vous avez choisi le niveau "+n);
            currentLevel = n;
            screen = "screenLevel";
        }
    }


    /* Displays current level
    At the end of the level, asks player if he wants to retry, go to the next level if there is one or to return to the menu
    */
    public void screenLevel(){
        Level level = new Level(currentLevel);
        displayLevel(level);
        do{
            int[] pos = player.choosePos(level);
            level.playTurn(pos[0], pos[1]);
            displayLevel(level);
        }while(!level.isLost() && !level.isWon());
        if(level.isWon()){
            level.bonusPoint();
            displayLevel(level);
            System.out.println("Bravo! Vous avez sauvé tous les animaux avec un score de "+level.getScore());

            int maxL = player.getMaxLevel();
            if(currentLevel == maxL && currentLevel < nLevels){
                player.setMaxLevel(maxL+1);
            }

            ArrayList<Integer> bestScores = player.getScores();
            if(bestScores.size() < currentLevel){
                bestScores.add(level.getScore());
            } else {
                if(bestScores.get(currentLevel-1) < level.getScore()){
                    bestScores.set(currentLevel-1, level.getScore());
                }
            }

            player.save(name);
            
            String[] proposition;
            if(currentLevel < nLevels){
                System.out.println("Rejouer au meme niveau \"rejouer\", passer au niveau suivant \"suivant\" ou retourner au menu des niveaux \"retourner\"");
                String[] proposition1={"rejouer","play","suivant","next","retourner","return"};
                proposition = proposition1;
            } else {
                System.out.println("Rejouer au meme niveau \"rejouer\" ou retourner au menu des niveaux \"retourner\"");
                String[] proposition2={"rejouer","play","retourner","return"};
                proposition = proposition2;
            }

            String choice = player.choosePlay(proposition);
            if(choice.equals("rejouer")||choice.equals("play")){
                screen = "screenLevel";
            }else if(choice.equals("suivant")||choice.equals("next")){
                currentLevel++;
                screen="screenLevel";  
            }else{
                screen="levelsMenu";
            }
        }else{
            displayLevel(level);
            System.out.println("Les animaux n'ont pas pu être tous sauvés, vous avez perdu!");
            System.out.println("Rejouer au meme niveau \"rejouer\" ou retourner au menu des niveaux \"retourner\"");
            String[] propostion = {"rejouer","play","retourner","return"};
            String choice = player.choosePlay(propostion);
            if(choice.equals("rejouer")||choice.equals("play")){
                screen = "screenLevel";
            }else{
                screen = "levelsMenu";
            }
        }
    }

    //Displays the level taken in parameter
    public void displayLevel(Level level){
        Box[][] boxes = level.getBoxes();
        int score  = level.getScore();
        int turns = level.getTurns();

        System.out.println();
        System.out.println("Score: "+score);
        if(turns != -1) System.out.println(turns+" turns left");
        System.out.println();
        System.out.print("  ");
        for(int i=0;i<boxes[0].length;i++){System.out.print(i);}
        System.out.println();
        char letter='A';
        for(int i = 0; i < boxes.length; i++){
            System.out.print((letter++)+" ");
            for(int j = 0; j < boxes[i].length; j++){
                if(level.isEmpty(i, j)){
                    System.out.print(" ");
                } else {
                    System.out.print(boxes[i][j]);
                }
            }
            System.out.println();
        }
        System.out.print("  ");
        System.out.println();
    }
}
    
