import java.util.LinkedList;

//Represents any type of object that is contained inside a level
public class Box {
    //For a single type of Box there may be multiple images that can represent it, this attribute designates which image is showed for this box
    private int imageIndex;
    //This list stores the path the box takes during a turn in order to animate the boxes in the GUI
    private LinkedList<int[][]> moves;

    public Box(int imageIndex){
        this.imageIndex = imageIndex;
        moves = new LinkedList<int[][]>();
    }

    public int getImageIndex(){
        return imageIndex;
    }

    //Is called at the beginning of a turn
    public void clearMoves(){
        moves = new LinkedList<int[][]>();
    }
    
    //Adds a move from the position (i, j) to the position (i2, j2)
    public void addMove(int i, int j, int i2, int j2){
        int[][] t = {{i, j},{i2, j2}};
        moves.add(t);
    }

    //Changes the ending position of the last move to (i, j)
    public void continueMove(int i, int j){
        int[][] t = moves.getLast();
        t[1][0] = i;
        t[1][1] = j;
    }

    //Is called when the box is destroyed
    public void addMoveDestroy(){
        int[][] t = {{-1, -1},{-1, -1}};
        moves.add(t);
    }

    //Changes the last move to a destroy move
    public void setMoveDestroy(){
        int[][] t = {{-1, -1},{-1, -1}};
        moves.set(moves.size()-1, t);
    }

    public LinkedList<int[][]> getMoves(){
        return moves;
    }
}
