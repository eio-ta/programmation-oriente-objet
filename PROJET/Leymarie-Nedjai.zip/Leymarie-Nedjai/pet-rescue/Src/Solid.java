//A box that cannot move: it does not fall or go to the left
public class Solid extends Box{
    //If true, the pets are rescued when they land on top of this box
    private boolean ground;

    public Solid(int imageIndex, boolean ground){
        super(imageIndex);
        this.ground = ground;
    }
    
    public boolean isGround(){
        return ground;
    }

    public String toString(){
        return "#";
    }
}