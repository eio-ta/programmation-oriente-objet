//A pet that the player have to rescue
public class Pet extends Box{

    public Pet(int imageIndex){
        super(imageIndex);
    }
    
    public String toString(){
        return "p";
    }
}
