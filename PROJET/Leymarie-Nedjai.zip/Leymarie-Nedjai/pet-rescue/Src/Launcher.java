import java.awt.*;

/* This class launches the game
    It firstly asks if the player is a human or a robot
    Then asks if the human player wants to play in graphic or terminal view
 */
public class Launcher{

    public static void main(String[] args){
        Player player = new Human();

        System.out.println("Bienvenue! Voulez-vous que le robot joue à votre place? (oui/non)");        
        String[] choices = {"yes","no","y","n","oui","non","o"};
        String typePlayer = player.choosePlay(choices);
        
        if(typePlayer.equals("yes")||typePlayer.equals("y")||typePlayer.equals("oui")||typePlayer.equals("o")){
            player = new Robot();
            TerminalView terminalView = new TerminalView(player);
            terminalView.play();
        }else{
            System.out.println("Voulez-vous passer en vue graphique? (oui/non)");
            String typeView = player.choosePlay(choices);
    
            if(typeView.equals("yes")||typeView.equals("y")||typeView.equals("oui")||typeView.equals("o")){
                final Player p = player;
                EventQueue.invokeLater(()->{
                    GraphicView graphicView = new GraphicView(p);
                });
                
                
            }else{
                TerminalView terminalView = new TerminalView(player);
                terminalView.play();
            }
        }
    }

        
}