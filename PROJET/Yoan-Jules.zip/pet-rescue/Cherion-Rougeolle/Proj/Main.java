import jeu.*;

public class Main{
	public static void main(String[] args) {
		Jeu j = new Jeu();
	}

}
