import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.UndoManager;

public class ImageEditModel {
	private BufferedImage image;
	UndoManager undoManager = new UndoManager();
	
	public ImageEditModel(String chemin) throws IOException {
		this.image = ImageIO.read(new File(chemin));
	}

	public BufferedImage getImage() {
		return image;
	}
	
	public void fillzone(Rectangle z, int[][] pixels) {
		if(z.height == pixels.length && z.width == pixels[0].length) {
			for(int i=0; i<pixels.length; i++) {
				for(int j=0; j<pixels[i].length; j++) {
					image.setRGB(z.x+j, z.y+i, pixels[i][j]);
				}
			}
		} else {
			System.out.println("erreur : mauvais format !");
		}
	}
	
	public void clearzone(Rectangle z) {
		Color color = Color.white;
		int srgb = color.getRGB();
		int[][] pixels = new int[z.height][z.width];
		for(int i=0; i<pixels.length; i++) {
			for(int j=0; j<pixels[i].length; j++) {
				pixels[i][j] = srgb;
			}
		}
		fillzone(z, pixels);
	}
	
	public void saveCut(Rectangle z) {
		BufferedImage sousImage = image.getSubimage((int) z.getMinX(), (int) z.getMinY(), (int) z.getWidth(), (int) z.getHeight());
		Coupe c = new Coupe((int) z.getMinX(), (int) z.getMinY(), (int) z.getWidth(), (int) z.getHeight(), sousImage);
		c.doit();
		CutEdit cut = new CutEdit(c);
		cut.addEdit(undoManager);
	}
	
	public class Coupe {
		private Rectangle z;
		private int[][] pixels;
		
		public Coupe(int x1, int y1, int width, int heigth, BufferedImage image) {
			z = new Rectangle(x1, y1, width, heigth);
			pixels = new int[heigth][width];
			for(int y=0; y<heigth; y++) {
				for(int x=0; x<width; x++) {
					pixels[y][x] = image.getRGB(x, y);
				}
			}
		}
		
		public void doit() {
			clearzone(z);
		}
		
		public void undo() {
			fillzone(z, pixels);
		}
	}
	
	public class CutEdit extends AbstractUndoableEdit {
		private Coupe c;
		
		public CutEdit(Coupe c) {
			this.c = c;
		}
		
		public void undo() {
			super.undo();
		}
		
		public void redo() {
			super.redo();
		}
	}
	

}
